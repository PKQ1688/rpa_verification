# -*- coding:utf-8 -*-
# @author :adolf
import gvcode

s, v = gvcode.generate()    #序列解包

print(s)

print(v)